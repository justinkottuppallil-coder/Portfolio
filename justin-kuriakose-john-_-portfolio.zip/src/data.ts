export const personalInfo = {
  name: "Justin Kuriakose John",
  title: "Electrical Engineer | MSc Student",
  email: "justinkottuppallil@gmail.com",
  phone: "+43 670 190 5678",
  location: "Villach, Austria",
  linkedin: "https://linkedin.com/in/justin-kuriakose-john-7a5390213",
  profileImage: "/portrait.jpg",
  summary: "Master's student in Electrical Energy and Mobility Systems at FH Kärnten with a strong background in power systems and renewable energy. A motivated and hardworking engineer passionate about sustainable energy solutions with extensive experience in PV system modeling and grid integration.",
};

export const experiences = [
  {
    company: "ADMiRE Research Center",
    role: "Research Intern",
    location: "Villach, Austria",
    period: "2025 – Present",
    points: [
      "Built a power electronics test setup for photovoltaic (PV) module performance evaluation.",
      "Conducted real-time testing using Speedgoat for machine and PV system analysis.",
      "Applied MATLAB/Simulink for system-level modeling, optimization, and fault tolerance enhancement.",
      "Developed CAD drawings and estimated the Bill of Materials (BOM) for an island energy system project.",
    ],
  },
  {
    company: "Kerala State Electricity Board",
    role: "Engineering Trainee",
    location: "Kerala, India",
    period: "Aug 2023 – Sep 2024",
    points: [
      "Performed electrical failure investigations and root cause analysis on high-voltage distribution systems (11kV feeders, transformers, and switchgear).",
      "Performed battery maintenance and health checks for substation and backup power systems.",
      "Supported real-time synchronization and troubleshooting of hydro, solar, and substation systems.",
      "Participated in maintenance and testing of 3×5 MW hydroelectric systems and 33/11kV VCBs with SCADA integration.",
    ],
  },
  {
    company: "Thinkfon-tech Thalassery",
    role: "Engineering Intern",
    location: "Kerala, India",
    period: "Dec 2022 – Apr 2023",
    points: [
      "Simulated and tested DC-DC converter circuits (buck, boost, buck-boost) for system reliability optimization.",
      "Modeled AC/DC conversion stages to identify loss mechanisms and develop efficient control strategies.",
    ],
  },
  {
    company: "ABR Solar Wayanad",
    role: "Engineering Intern",
    location: "Kerala, India",
    period: "Jan 2019 – Jul 2019",
    points: [
      "Installed and tested solar PV modules and inverters, performing failure detection and DC/AC system validation.",
      "Monitored system behavior under variable conditions to understand fault patterns and energy yield issues.",
    ],
  },
  {
    company: "KFC Villach",
    role: "Shift Manager",
    location: "Villach, Austria",
    period: "Ongoing",
    points: [
      "First and only student visa holder in Austria with this role.",
      "Planned and implemented labor and sales cost strategies.",
      "Supervised operational standards, hygiene compliance, and equipment maintenance.",
    ],
  },
];

export const education = [
  {
    degree: "MSc Electrical Energy & Mobility Systems",
    institution: "FH Kärnten – Carinthia University of Applied Sciences",
    location: "Villach, Austria",
    period: "Oct 2024 – Present",
  },
  {
    degree: "B.E Electrical and Electronics Engineering",
    institution: "APJ Abdul Kalam Technological University",
    location: "Kerala, India",
    period: "Jul 2019 – Jun 2023",
  },
];

export const projects = [
  {
    title: "Test Bench for Prosthetic Limb Monitoring Systems",
    period: "Feb 2026 – Ongoing",
    description: "Developed a multi-sensor experimental test bench using ESP32 DevKit for prosthetic applications. Integrated PPG and thermal sensing systems with heater control and safety mechanisms.",
    details: "Performed signal processing and hardware interfacing (MOSFET-based) for biomedical measurements and feasibility analysis.",
  },
  {
    title: "Real-Time MPPT Controlled Solar PV Boost Converter System",
    period: "Sep 2025 – Feb 2026",
    description: "Developed a MATLAB/Simulink based solar PV system with P&O MPPT algorithm for maximum power extraction. Designed and optimized a DC-DC boost converter with PWM control for HIL testing.",
    details: "Validated the control model on Speedgoat IO334 hardware for real-time renewable energy applications.",
  },
  {
    title: "DC Motor Monitoring and PWM Control Using NI myDAQ",
    period: "Jun 2025",
    description: "Developed a PWM-based 24 V DC motor control and monitoring system using NI myDAQ and LabVIEW. Implemented real-time current acquisition and power estimation using DAQmx analog input/output functions.",
    details: "Designed and tested practical hardware interfacing involving PWM modules, motor control, and sensor-based measurements.",
  },
  {
    title: "Water Pipeline Monitoring and Leak Detection",
    period: "Feb 2023 – May 2023",
    description: "Bachelor Thesis. Built a real-time water leak detection system using YF-G1-DN2, Arduino ATmega328P, and NodeMCU ESP8266.",
    details: "Integrated an Android app for remote alerts and precise leak localization via flow anomaly algorithms. Awarded at NACONEST-23.",
  },
  {
    title: "PV Module Performance Analysis and Optimization",
    period: "Jan 2022 – May 2022",
    description: "Developed a system to analyze harmonics and variable parameters in solar panels.",
    details: "Assessed the impact of solar fluctuations on transformer efficiency and grid stability.",
  },
  {
    title: "Design and making of Electric Buggy",
    period: "Aug 2021 – Dec 2021",
    description: "Built and debugged BLDC motor control systems and battery management.",
    details: "Implemented regenerative braking circuits for efficiency testing.",
  },
];

export const skills = {
  technical: [
    "Electrical Circuit Analysis",
    "Power System Protection",
    "DC-DC Conversion",
    "Grid Synchronization",
    "PV Systems",
    "Reliability Analysis",
    "Energy Storage",
  ],
  software: [
    "MATLAB/Simulink",
    "PLECS",
    "LabVIEW",
    "AutoCAD Electrical",
    "SolidWorks Electrical",
    "Python",
    "KiCad",
  ],
  hardware: [
    "Speedgoat Real-time Testing",
    "Microcontrollers (Arduino/NodeMCU)",
    "Li-ion & Na-ion Battery Testing",
    "VCBs",
    "SCADA Integration",
  ],
  languages: [
    "English (C1)",
    "German (A2)",
    "Malayalam (Native)",
  ],
};

export const publications = [
  {
    title: "Water Pipeline monitoring and leak detection using water flow meter",
    conference: "National Conference on Novel Engineering Science and Technology (NACONEST- 23)",
    date: "04/09/2023",
  },
];
